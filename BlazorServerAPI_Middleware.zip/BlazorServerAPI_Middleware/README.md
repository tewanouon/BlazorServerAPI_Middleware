# BlazorTwoProjects (API + Blazor UI)

## Ports
- API: https://localhost:5101 (Swagger enabled)
- UI : https://localhost:5201

## Run (two terminals)
```
dotnet run --project ApiHost/ApiHost.csproj
dotnet run --project BlazorUi/BlazorUi.csproj
```
Login at /login (admin/manager/user). Then test Home (Approve) and Proxy Demo.
