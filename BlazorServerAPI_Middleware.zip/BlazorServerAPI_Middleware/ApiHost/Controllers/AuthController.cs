using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace ApiHost.Controllers;

[ApiController]
[Route("auth")]
public class AuthController : ControllerBase
{
    private readonly IConfiguration _cfg;
    public AuthController(IConfiguration cfg) => _cfg = cfg;

    [HttpPost("token")]
    public IActionResult Token([FromBody] LoginDto dto)
    {
        var role = dto.Username switch
        {
            "admin" => ("admin","manager"),
            "manager" => ("manager","manager"),
            "user" => ("user","staff"),
            _ => default((string,string))
        };
        if (role == default || (dto.Username == "user" ? dto.Password != "password" : dto.Password != "P@ssw0rd!"))
            return Unauthorized(new { message = "Invalid username or password" });

        var issuer = _cfg["Jwt:Issuer"]!;
        var audience = _cfg["Jwt:Audience"]!;
        var key = _cfg["Jwt:Key"]!;
        var signing = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));

        var claims = new List<Claim>{
            new Claim(ClaimTypes.Name, dto.Username),
            new Claim(ClaimTypes.Role, role.Item1),
            new Claim("approval_level", role.Item2),
            new Claim("scope", "api.read")
        };

        var token = new JwtSecurityToken(
            issuer: issuer, audience: audience, claims: claims,
            expires: DateTime.UtcNow.AddHours(8),
            signingCredentials: new SigningCredentials(signing, SecurityAlgorithms.HmacSha256));

        return Ok(new { access_token = new JwtSecurityTokenHandler().WriteToken(token), token_type = "Bearer" });
    }
}

public record LoginDto(string Username, string Password);
