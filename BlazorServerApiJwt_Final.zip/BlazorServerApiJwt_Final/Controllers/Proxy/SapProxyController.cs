using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BlazorServerApiJwt_Final.Controllers.Proxy;

[ApiController]
[Route("api/proxy/sap")]
public class SapProxyController : ControllerBase
{
    [HttpGet("items")]
    [Authorize(Policy="ApiScope")]
    public IActionResult Items()
        => Ok(new[]{ new { ItemCode="SP-001", ItemName="Spare Part A", Price=1200M } });
}
