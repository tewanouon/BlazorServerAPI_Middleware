# BlazorServerApiJwt_Final
Blazor Server (.NET 8) + JWT Bearer (no cookies) + Internal API + Proxy demo
- Uses NavigationManager.ToAbsoluteUri for all API calls

## Run
dotnet restore
dotnet run

Open http://localhost:5000

## Demo accounts
- admin / P@ssw0rd!  (CanApprove)
- manager / P@ssw0rd! (CanApprove)
- user / password     (read only)
