using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Extensions.Http.Resilience;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

var issuer = builder.Configuration["Jwt:Issuer"] ?? "DemoIssuer";
var audience = builder.Configuration["Jwt:Audience"] ?? "DemoAudience";
var key = builder.Configuration["Jwt:Key"] ?? "CHANGE_ME_SECRET_KEY_32CHARS_MINIMUM";

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateIssuerSigningKey = true,
            ValidateLifetime = true,
            ValidIssuer = issuer,
            ValidAudience = audience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key))
        };
    });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("CanApprove", p => p.RequireClaim("approval_level", "manager", "admin"));
    options.AddPolicy("ApiScope", p => p.RequireClaim("scope", "api.read"));
});

builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddControllers();

builder.Services.AddHttpClient("sap", c =>
{
    c.BaseAddress = new Uri(builder.Configuration["Sap:BaseUrl"] ?? "https://example.com");
    c.Timeout = TimeSpan.FromSeconds(15);
}).AddStandardResilienceHandler();

var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
